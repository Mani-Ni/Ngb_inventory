<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class Customer extends Model
{
    //
    protected $table = "customer";

    public function allCustomer()
    {
                        /*->leftJoin('payment','customer.id','=','payment.customer_id')*/
        return DB::table('customer')
                        ->select('id','name','email','phone','address','status')
                        ->orderBy('id','DESC')
                        ->get();
    }

}
