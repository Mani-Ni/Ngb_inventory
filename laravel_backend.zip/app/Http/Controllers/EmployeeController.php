<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Employee;
use App\Models\Setting;
use App\Models\Menu;
use App\Models\Submenu;
use App\Models\UserRole;
use App\User;
use JWTAuth; 
use Excel;
use App\Libraries\EmployeePDF;
class EmployeeController extends Controller
{
    /**
     * @param  \App\CommonModel  $commonModel
     * @return \Illuminate\Http\Response
     */
    public function employeeSave(Request $request)
    {

        $employee = new User;
        $employee->name = $request->input('name');
        $employee->email = $request->input('email');
        $employee->phone = $request->input('phone');
        $employee->address = $request->input('address');
        $employee->password = bcrypt($request->input('password'));
        $employee->save();

        return response()->json(['status'=>200,'mesg'=>'Employee Save Success']); 
    }

    

   /* public function roleData(Request $request)
    {   
        $data = array (
                          'data' => 
                          array (
                            0 => array (
                              'label' => 'Dashboard',
                              'data' => 'dashboard',
                              'icon' => 'fa fa-home',
                              'route' => '/dashboard',
                              'children' => null,
                              'type' => null
                            ),
                            1 => array (
                              'label' => 'Customer',
                              'data' => 'customer',
                              'icon' => 'fa fa-laptop',
                              'route' => '/customer',
                              'children' => null,
                              'type' => null
                            ),
                            2 => 
                            array (
                              'label' => 'Product Manage',
                              'data' => 'productManage',
                              'icon' => 'fa fa-laptop',
                              'icon' => 'fa fa-product-hunt',
                              'type' => 1,
                              'children' => 
                              array (
                                0 => 
                                array (
                                  'label' => 'Category',
                                  'data' => 'category',
                                  'parent' => 'productManage',
                                  'route' => '/category',
                                  'type' => 0,
                                ),
                                1 => 
                                array (
                                  'label' => 'Sub Category',
                                  'data' => 'subCategory',
                                  'parent' => 'productManage',
                                  'route' => '/subCategory',
                                  'type' => 0,
                                ),
                                2 => 
                                array (
                                  'label' => 'Product',
                                  'data' => 'product',
                                  'parent' => 'productManage',
                                  'route' => '/product',
                                  'type' => 0,
                                ),
                                3 => 
                                array (
                                  'label' => 'Damaged Product',
                                  'data' => 'damagedProduct',
                                  'parent' => 'productManage',
                                  'route' => '/damaged-product',
                                  'type' => 0,
                                )
                              ),
                            ),
                            3 => 
                            array (
                              'label' => 'Manage Purchases',
                              'data' => 'managePurchases',
                              'icon' => 'fa fa-shopping-bag',
                              'parent' => 'managePurchases',
                              'type' => 1,
                              'children' => 
                              array (
                                0 => 
                                array (
                                  'label' => 'New Purchases',
                                  'data' => 'newPurchases',
                                  'parent' => 'managePurchases',
                                  'route' => '/purchases',
                                  'type' => 0
                                ),
                                1 => 
                                array (
                                  'label' => 'Purchases History',
                                  'data' => 'purchasesHistory',
                                  'parent' => 'managePurchases',
                                  'route' => '/purchases-history',
                                  'type' => 0
                                )
                              ),
                            ),
                            4 => 
                            array (
                              'label' => 'Manage Order',
                              'data' => 'manageOrder',
                              'icon' => 'fa fa-files-o',
                              'parent' => 'manageOrder',
                              'type' => 1,
                              'children' => 
                              array (
                                0 => 
                                array (
                                  'label' => 'New Order',
                                  'data' => 'newOrder',
                                  'parent' => 'manageOrder',
                                  'route' => '/order',
                                  'type' => 0
                                ),
                                1 => 
                                array (
                                  'label' => 'Order History',
                                  'data' => 'orderHistory',
                                  'parent' => 'manageOrder',
                                  'route' => '/order-history',
                                  'type' => 0
                                )
                              ),
                            )
                          ),
                        );
        return response()->json($data);
    }*/


}
