<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Category;
use App\Models\SubCategory;
use App\Models\Product;
use JWTAuth;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function getAllCategoryByGrid(Request $request)
    {
        $all = Category::select()->orderBy('id', 'desc')->get();           
        return response()->json(['status'=>200,'cat'=>$all]); 
    }

    public function getAllCategory(Request $request)
    {
        $all = Category::where('status',1)->get();           
        return response()->json(['status'=>200,'cat'=>$all]); 
    }

    public function categorySave(Request $request)
    {
        
        $category = new Category;
        $category->name = $request->input('category');
        $category->description = $request->input('description');
        $category->status = $request->input('status');
        $category->save();
        
        return response()->json(['status'=>200,'mesg'=>'Category Save Success']);
    }

    public function getCategory(Request $request)
    {
        $id = $request->input('id');
        $find = Category::where('id',$id)->first();           
        return response()->json(['status'=>200,'cat'=>$find]); 
    }

    public function categoryUpdate(Request $request)
    {
        $id = $request->input('id');
        $category = Category::find($id);
        $category->name = $request->input('category');
        $category->description = $request->input('description');
        $category->status = $request->input('status');
        $category->save();
        
        return response()->json(['status'=>200,'mesg'=>'Category Update Success']);
    }

    public function categoryDelete(Request $request)
    {
        $id = $request->input('id');
        $product = Product::select(DB::raw('count(id) as total'))->where('category_id',$id)->first();
        if($product->total==0){
            $cat= Category::find($id);
            $cat->delete();
            $status = 200;
        }else{
            $status = 400;
        }
        return response()->json(['status'=>$status]);
    }


    public function getCatBySubCategory(Request $request)
    {
        $id = $request->input('id'); 
    	$all = SubCategory::where('status',1)->where('category_id',$id)->get();           
        return response()->json(['status'=>200,'subCat'=>$all]);
    }

    public function subCategoryGridData(Request $request)
    {
        $all =  DB::table('sub_category')
                        ->join('category', 'sub_category.category_id', '=', 'category.id')
                        ->select('sub_category.id','sub_category.name','sub_category.description','category.name as categoryName','sub_category.status')
                        ->orderBy('sub_category.id', 'desc')
                        ->get();

        echo json_encode(array('status'=>200,'subCat'=>$all));  
    }

    public function subCategorySave(Request $request)
    {
        $subCategory = new SubCategory;
        $subCategory->name = $request->input('subCategory');
        $subCategory->category_id = $request->input('category');
        $subCategory->description = $request->input('description');
        $subCategory->status = $request->input('status');
        $subCategory->save();
        return response()->json(['status'=>200,'mesg'=>'Sub Category Save Success']);
    }

    public function getSubCategory(Request $request)
    {
        $id = $request->id;
        $find = SubCategory::find($id);           
        return response()->json(['status'=>200,'subCat'=>$find]);
    }

    public function subCategoryUpdate(Request $request)
    {
        $id = $request->id;
        $subCategory = SubCategory::find($id);
        $subCategory->name = $request->input('subCategory');
        $subCategory->category_id = $request->input('category');
        $subCategory->description = $request->input('description');
        $subCategory->status = $request->input('status');
        $subCategory->save();
        return response()->json(['status'=>200,'mesg'=>'Category Update Success']);
    }


    public function subCategoryDelete(Request $request)
    {
        $id = $request->input('id');
        $cat= SubCategory::find($id);
        $cat->delete();
        return response()->json(['status'=>200,'mesg'=>'subCategory delete Success']);
    }
    
}
