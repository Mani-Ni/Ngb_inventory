<?php
namespace App\Libraries;
use Anouar\Fpdf\Fpdf as baseFpdf;
class UserPDF extends baseFpdf
{

	public function __construct()
	{
		$orientation = 'L';
		$unit = 'mm';
		$size = 'A4';
		parent::__construct($orientation, $unit, $size);
	}
	// Page header
	/*function Header()
	{
	    // Logo
	    // $this->Image('logo.png',10,6,30);
	    // Arial bold 15
	    $this->SetFont('Arial','B',15);
	    // Move to the right
	    $this->Cell(80);
	    // Title
	    $this->Cell(30,10,'Title',1,0,'C');
	    // Line break
	    $this->Ln(20);
	}*/

	function Header()
    {
	if($this->PageNo() != 1){

    	/*$this->SetFont('Arial','B',15);
	    // Move to the right
	    $this->Cell(80);
	    // Title
	    $this->Cell(30,10,'Title',1,0,'C');
	    // Line break
	    $this->Ln(20);*/
	    $this->SetFont('Arial','B',12);
        $this->cell(10,6,"SL",1,"","C");
        $this->cell(45,6,"Name",1,"","C");
        $this->cell(45,6,"Email",1,"","C");
        $this->cell(45,6,"Phone",1,"","C");
        $this->cell(35,6,"Address",1,"","C");
        $this->cell(20,6,"Type",1,"","C");
        $this->cell(20,6,"Status",1,"","C");
		//$this->Cell(35,5,'User','TRB',0,'C');
		$this->Ln(); // Line break

	}


	
    }

    function SetCellMargin($margin){
        // Set cell margin
        $this->cMargin = $margin;
    }
   /* function body()
	{
		//Report Header
		$this->SetFont('Arial','B',12);
		$this->Cell(5);
		$this->Cell(200,5,'Client Transaction Record List',0,1,'L');
		$this->SetFont('Arial','B',8);
		$this->Cell(5);
		$this->Cell(200,3,'Period : '.date('d-M-Y', strtotime($this->start_date)).' to '.date('d-M -Y', strtotime($this->end_date)),0,1,'L');
		$this->Cell(5);
		$this->Cell(200,3,'Print Date : '.date('d-M-Y H:i:s a'),0,1,'L');
		$this->Ln(5);
		//End Report Header

			$this->SetFont('Arial','B',8);
			$this->Cell(5);
			$this->Cell(10,5,'SL #',1,0,'C');
			$this->Cell(18,5,'Date',1,0,'C');
			$this->Cell(25,5,'Invoice No','TRB',0,'C');
			$this->Cell(15,5,'Profile ID','TRB',0,'C');
			$this->Cell(70,5,'Customer Name','TRB',0,'C');
			$this->Cell(60,5,'Customer Address','TRB',0,'C');
			$this->Cell(10,5,'Type','TRB',0,'C');
			$this->Cell(18,5,'Billed (BDT)','TRB',0,'C');
			$this->Cell(23,5,'Received (BDT)','TRB',0,'C');
			$this->Cell(22,5,"Payment Mode",'TRB',0,'C');
			//$this->Cell(35,5,'User','TRB',0,'C');
			$this->Ln(5); // Line break

		//Start Loop Here
		$num_loop = count($this->gridData);
		$total_received = 0;
		$total_billed = 0;

		for($i=0; $i<$num_loop; $i++){
			$row_height = 5; // set the default
			$column_width = 15;
			$number_of_lines = ceil( $this->GetStringWidth('Multiplant Avilash, House # 524, Roadr # 11, Baitul Aman Housing Socity , Adabor, Mohammadpur, Dhaka-1207') / ($column_width - 1) );
			$cell_height = 5;
			$height_of_cell = ceil( $number_of_lines * $cell_height );
			if ( $cell_height > $row_height ) {
				$row_height = $cell_height;
			}

			$this->SetFont('Arial','',7);
			$this->Cell(5);
			$this->Cell(10,5,$i+1,1,0,'C');
			$this->Cell(18,5,date('d-M-Y', strtotime($this->gridData[$i]['DATE_TIME'])),1,0,'C');
			$this->Cell(25,5,$this->gridData[$i]['INVOICE_ID'],'TRB',0,'C');
			$this->Cell(15,5,$this->gridData[$i]['CLIENT_PROFILE_ID'],'TRB',0,'R');
			$this->Cell(70, 5,ucwords(strtolower($this->gridData[$i]['COMPANY_NAME'])),'TRB',0,'L');
			$this->Cell(60, 5, $this->gridData[$i]['ADDRESS2'], 1);
			$this->Cell(10,5,$this->gridData[$i]['TYPE_NAME'],'TRB',0,'C');
			$this->Cell(18,5,$this->gridData[$i]['BILLED'],'TRB',0,'R');
			$this->Cell(23,5,$this->gridData[$i]['RECEIVED'],'TRB',0,'R');
			$this->Cell(22,5,$this->paymentMode($this->gridData[$i]['PAYMENT_MODE']),'TRB',0,'C');
			//$this->Cell(35,5,ucwords($this->gridData[$i]['NAME']),'TRB',0,'L');
			$this->Ln(5);
			@$total_received += $this->gridData[$i]['RECEIVED'];
			@$total_billed += $this->gridData[$i]['BILLED'];
		}
		//End Loop Here
		//Total Amount
		$this->Ln(5);
		$this->SetFont('Arial','B',8);
		$this->Cell(5);
		$this->Cell(273,5,'Total Received : ' . $total_received . '.00 BDT' ,0,1,'L');
		//Total Current Due
		$this->SetFont('Arial','B',8);
		$this->Cell(5);
		$this->Cell(273,5,'Total Billed : ' . $total_billed . '.00 BDT' ,0,1,'L');
	}*/


	// Page footer
	function Footer()
	{
	    // Position at 1.5 cm from bottom
	    $this->SetY(-15);
	    // Arial italic 8
	    $this->SetFont('Arial','I',8);
	    // Page number
	    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
	}


}