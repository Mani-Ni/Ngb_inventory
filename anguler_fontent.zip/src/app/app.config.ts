﻿export const appConfig = {
    apiUrl: 'http://angular.nanoseotools.com/km/laravel_backend'
};