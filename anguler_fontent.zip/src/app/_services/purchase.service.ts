import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';


@Injectable()
export class PurchaseService {

  constructor(private http:HttpClient) { }

  save(data){
  	return this.http.post('/api/product-save', data);
  }

  getAllSupplier(){
    return this.http.get('/api/get-all-supplier-by-purchases');
  }

  getAllProduct()
  {
    return this.http.get('/api/get-all-purchasesProduct');
  }

  getCategoryByPurchases(id){
    return this.http.post('/api/get-productForPurchases',{productId:id});
  }

  createNewPurchase(data){
    return this.http.post('/api/create-new-purchase',data);
  }
}