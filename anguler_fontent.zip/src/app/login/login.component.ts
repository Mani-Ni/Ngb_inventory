import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
// import  { AuthenticationService } from '../service/authentication/authentication.data.service';
import { AlertService, AuthenticationService, SettingService} from '../_services/index';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
// import $ from 'jquery/dist/jquery';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(
            private route: ActivatedRoute,
            public router: Router,
            private dataService:AuthenticationService,
            private setingService:SettingService,
            private alertService: AlertService
          ) { }
    username: string;
    password: string;
    token:string;
    textMesg:any;
    show: boolean = false;

    model: any = {};
    loading = false;
    returnUrl: string;
    setting = {image:''};
    ngOnInit() { 
      
      if (localStorage.getItem('currentUser') !=null) {
        // this.router.navigate(['/dashboard']);
      }
      // get return url from route parameters or default to '/'
      // this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';

      this.setingService.getSettingData()
            .pipe().subscribe(data => { 
                        this.setting = {image:data['setting'].image}                        
            });
    }

   
    onLoggedin() {
    	this.loading = true;
	    
      var UserInput = {
        	'email': this.model.username,
	    	'password': this.model.password
	    };
      
      if(this.model.username !=undefined  && this.model.password != undefined){

	      this.dataService.login(UserInput)
	          .pipe().subscribe(
	              data => {
	                  if(data.status==400){
	                  	this.show = true;
	                  	this.textMesg = data.mesg;
	                    this.loading = false;
                    }else if(data.status==500){
                      this.show = true;
                      this.textMesg = data.mesg;
                      this.loading = false;
                    }else if(data.status==300){
                      this.show = true;
                      this.textMesg = data.mesg;
                      this.loading = false;
	                  }else{
                      this.router.navigate(['/dashboard']);
	                  }
	              },
	              error => {
	                  this.alertService.error(error);
	              });
      }
    
  }

}
